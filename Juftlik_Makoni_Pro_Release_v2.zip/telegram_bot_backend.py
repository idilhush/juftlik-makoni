"""
Juftlik Makoni — Telegram Bot Backend (aiogram 3.x + Supabase)
Features:
1. /start & WebApp Mini App button
2. /link LOVE-XXXX (Links Telegram user_id to app_users profile)
3. /addmusic (Uploads MP3 directly into linked couple space playlist)
4. Contact verification handler (Verifies contact.user_id == message.from_user.id before saving masked phone)
5. Super Admin commands: /stats, /users, /broadcast
"""

import asyncio
import hashlib
import os
import time
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import Command
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    WebAppInfo,
)
from supabase import create_client, Client

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
WEBAPP_URL = "https://idilhush.github.io/juftlik-makoni/"
SUPABASE_URL = "https://vncglehzpctlfzupzatl.supabase.co"
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "sb_publishable_XbXyPRW4ebp5VfjrwqbCww_yriC5Vul")
SUPER_ADMIN_TG_ID = int(os.getenv("SUPER_ADMIN_TG_ID", "0"))

sb: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

pending_music_upload = set()


def mask_phone(phone: str) -> str:
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) >= 9:
        return f"+{digits[:3]} ** *** {digits[-4:]}"
    return "***" + digits[-4:]


def hash_phone(phone: str) -> str:
    return hashlib.sha256(f"jm_phone_salt_{phone}".encode()).hexdigest()


@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🩵 Juftlik Makonini ochish", web_app=WebAppInfo(url=WEBAPP_URL))]
        ]
    )
    await message.answer(
        "Assalomu alaykum! 🩵 <b>Juftlik Makoni</b> botiga xush kelibsiz.\n\n"
        "• Profilingizni ulash uchun: <code>/link LOVE-XXXX</code>\n"
        "• Playlistga qo‘shiq yuklash uchun: <code>/addmusic</code>\n"
        "• Ilovani ochish uchun pastdagi tugmani bosing:",
        parse_mode="HTML",
        reply_markup=kb,
    )


@dp.message(Command("link"))
async def cmd_link(message: types.Message):
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Foydalanish: <code>/link LOVE-XXXX</code>", parse_mode="HTML")
        return

    invite_code = parts[1].strip().upper()
    res = sb.table("app_users").select("id, first_name, invite_code").eq("invite_code", invite_code).execute()
    if not res.data:
        await message.answer("❌ Bunday juftlik kodi topilmadi. Ilovadagi kodingizni tekshiring.")
        return

    user = res.data[0]
    sb.table("app_users").update(
        {
            "telegram_id": message.from_user.id,
            "tg_username": message.from_user.username,
        }
    ).eq("id", user["id"]).execute()

    await message.answer(
        f"✅ Tabriklaymiz, <b>{user['first_name']}</b>! Telegram profilingiz <code>{invite_code}</code> makoniga ulandi.\n"
        "Endi <code>/addmusic</code> buyrug‘i orqali to‘g‘ridan-to‘g‘ri qo‘shiq yuklashingiz mumkin 🎧",
        parse_mode="HTML",
    )


@dp.message(Command("addmusic"))
async def cmd_addmusic(message: types.Message):
    res = sb.table("app_users").select("id, first_name, space_key").eq("telegram_id", message.from_user.id).execute()
    if not res.data:
        await message.answer("⚠️ Avval profilingizni ulang: <code>/link LOVE-XXXX</code>", parse_mode="HTML")
        return

    pending_music_upload.add(message.from_user.id)
    await message.answer("🎧 Endi menga MP3 / Audio fayl yuboring — u avtomatik playlistingizga qo‘shiladi!")


@dp.message(F.audio)
async def handle_audio_upload(message: types.Message):
    if message.from_user.id not in pending_music_upload:
        return

    res = sb.table("app_users").select("id, first_name, space_key").eq("telegram_id", message.from_user.id).execute()
    if not res.data:
        return

    user = res.data[0]
    audio = message.audio
    if audio.file_size and audio.file_size > 15 * 1024 * 1024:
        await message.answer("⚠️ Audio fayl hajmi 15 MB dan kichik bo‘lishi kerak.")
        return

    file_info = await bot.get_file(audio.file_id)
    file_bytes = await bot.download_file(file_info.file_path)
    storage_path = f"audio/{user['space_key']}_{int(time.time())}.mp3"

    sb.storage.from_("couple-media").upload(storage_path, file_bytes.read(), {"content-type": "audio/mpeg"})
    public_url = sb.storage.from_("couple-media").get_public_url(storage_path)

    space_res = sb.table("couple_spaces").select("payload").eq("space_key", user["space_key"]).execute()
    payload = space_res.data[0]["payload"] if space_res.data else {"songs": []}
    songs = payload.get("songs", [])
    songs.insert(
        0,
        {
            "id": f"song_{int(time.time() * 1000)}",
            "title": audio.title or audio.file_name or "Telegram Audio",
            "artist": audio.performer or "Noma'lum ijrochi",
            "url": public_url,
            "playlist": "Umumiy playlist",
            "author": user["first_name"],
        },
    )
    payload["songs"] = songs
    sb.table("couple_spaces").upsert({"space_key": user["space_key"], "payload": payload}).execute()

    pending_music_upload.discard(message.from_user.id)
    await message.answer("✅ Qo‘shiq muvaffaqiyatli <b>Umumiy playlist</b>ga qo‘shildi! 🎶", parse_mode="HTML")


# ==================== SECURE PHONE CONTACT VERIFICATION ====================
@dp.message(Command("phone"))
async def cmd_request_phone(message: types.Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📱 Telefon raqamimni tasdiqlash", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await message.answer(
        "Telefon raqamingizni ixtiyoriy ravishda profilingizga bog‘lash uchun pastdagi tugmani bosing:",
        reply_markup=kb,
    )


@dp.message(F.contact)
async def handle_verified_contact(message: types.Message):
    contact = message.contact
    # Strict verification: contact must belong to the sender
    if not contact or contact.user_id != message.from_user.id:
        await message.answer("❌ Faqat o‘zingizning shaxsiy Telegram raqamingizni ulashingiz mumkin.", reply_markup=ReplyKeyboardRemove())
        return

    res = sb.table("app_users").select("id").eq("telegram_id", message.from_user.id).execute()
    if not res.data:
        await message.answer("⚠️ Avval /link LOVE-XXXX orqali profilingizni ulang.", reply_markup=ReplyKeyboardRemove())
        return

    phone_raw = contact.phone_number
    sb.table("app_users").update(
        {
            "phone_verified": True,
            "phone_masked": mask_phone(phone_raw),
            "phone_hash": hash_phone(phone_raw),
        }
    ).eq("id", res.data[0]["id"]).execute()

    await message.answer("✅ Telefon raqamingiz xavfsiz tarzda tasdiqlandi!", reply_markup=ReplyKeyboardRemove())


# ==================== SUPER ADMIN BOT COMMANDS ====================
@dp.message(Command("stats"))
async def cmd_admin_stats(message: types.Message):
    if SUPER_ADMIN_TG_ID and message.from_user.id != SUPER_ADMIN_TG_ID:
        return
    users = sb.table("app_users").select("id, partner_id, is_banned").execute().data or []
    paired = sum(1 for u in users if u.get("partner_id"))
    banned = sum(1 for u in users if u.get("is_banned"))
    await message.answer(
        f"📊 <b>Juftlik Makoni Statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{len(users)}</b>\n"
        f"🩵 Ulangan juftlik a'zolari: <b>{paired}</b>\n"
        f"🚫 Bloklanganlar: <b>{banned}</b>",
        parse_mode="HTML",
    )


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
