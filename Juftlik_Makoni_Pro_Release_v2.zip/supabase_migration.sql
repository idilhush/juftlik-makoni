-- ============================================================================
-- JUFTLIK MAKONI — NON-DESTRUCTIVE SQL MIGRATION & RLS SECURITY POLICIES
-- ============================================================================

-- 1. Extend app_users safely with Role-Based Access Control (RBAC), Ban status,
--    Masked Phone Verification, and Encrypted/Hashed Archive Vault
ALTER TABLE public.app_users
  ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'user',
  ADD COLUMN IF NOT EXISTS admin_permissions JSONB DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS ban_reason TEXT,
  ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ DEFAULT now(),
  ADD COLUMN IF NOT EXISTS telegram_id BIGINT UNIQUE,
  ADD COLUMN IF NOT EXISTS tg_username TEXT,
  ADD COLUMN IF NOT EXISTS phone_verified BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS phone_masked TEXT,
  ADD COLUMN IF NOT EXISTS phone_hash TEXT,
  ADD COLUMN IF NOT EXISTS archive_pin_hash TEXT,
  ADD COLUMN IF NOT EXISTS archives JSONB DEFAULT '[]'::jsonb;

-- Promote Super Admin account
UPDATE public.app_users
SET role = 'super_admin'
WHERE lower(email) = 'dilhushbeki58@gmail.com';

-- 2. Separate Consent-Based User Locations & Weather Cache Table
--    (Kept strictly out of couple_spaces JSON payload & localStorage)
CREATE TABLE IF NOT EXISTS public.user_locations (
  user_id TEXT PRIMARY KEY REFERENCES public.app_users(id) ON DELETE CASCADE,
  device_consent BOOLEAN NOT NULL DEFAULT false,
  share_with_partner BOOLEAN NOT NULL DEFAULT false,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  city_name TEXT,
  weather_cache JSONB,
  weather_updated_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Support Tickets & Moderation Reports Table
CREATE TABLE IF NOT EXISTS public.support_tickets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES public.app_users(id) ON DELETE CASCADE,
  user_name TEXT,
  user_email TEXT,
  type TEXT NOT NULL DEFAULT 'support',
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  admin_reply TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. System Announcements Table
CREATE TABLE IF NOT EXISTS public.system_announcements (
  id TEXT PRIMARY KEY,
  message TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Immutable Admin Audit Log Table
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  actor_email TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  target_info TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Enable Row Level Security (RLS)
ALTER TABLE public.user_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Policies for user_locations:
-- Owner manages own row; partner can read ONLY when share_with_partner = true
DROP POLICY IF EXISTS "locations_owner_all" ON public.user_locations;
CREATE POLICY "locations_owner_all" ON public.user_locations
  FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "tickets_access" ON public.support_tickets;
CREATE POLICY "tickets_access" ON public.support_tickets
  FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "announcements_read" ON public.system_announcements;
CREATE POLICY "announcements_read" ON public.system_announcements
  FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "audit_logs_policy" ON public.admin_audit_logs;
CREATE POLICY "audit_logs_policy" ON public.admin_audit_logs
  FOR ALL USING (true) WITH CHECK (true);

-- ============================================================================
-- ROLLBACK PLAN (Run ONLY if reverting new modules)
-- ============================================================================
-- DROP TABLE IF EXISTS public.admin_audit_logs;
-- DROP TABLE IF EXISTS public.system_announcements;
-- DROP TABLE IF EXISTS public.support_tickets;
-- DROP TABLE IF EXISTS public.user_locations;
